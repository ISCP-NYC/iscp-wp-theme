ace.define('ace/snippets/scss', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "scss";

});
